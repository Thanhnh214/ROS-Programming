#!usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan

class SmbHighlevelController:
    def __init__(self, scan_topic_name = "name", ):
        self.scan_subscriber = rospy.Subscriber("/scan", LaserScan, self.scan_callback, 10)

        def scan_callback(self.msg, _):
            distance = min(msg.ranges)
            rospy.loginfo("Min distance:" %02f)